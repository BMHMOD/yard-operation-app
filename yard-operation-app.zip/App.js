
import React, { useState } from "react";
import * as XLSX from "xlsx";
import { PieChart, Pie, Cell, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

export default function App() {
  const [data, setData] = useState([]);
  const [pieData, setPieData] = useState([]);
  const [occupancyData, setOccupancyData] = useState([]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const binaryStr = e.target.result;
      const workbook = XLSX.read(binaryStr, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(sheet);
      setData(jsonData);

      const categories = { "وارد": 0, "صادر": 0, "فوارغ": 0, "ترانزيت": 0 };
      const blockMap = {};

      jsonData.forEach((row) => {
        const type = row["نوع"] || "غير معروف";
        if (categories[type] !== undefined) categories[type] += 1;

        const block = row["Block"] || row["block"] || "غير معروف";
        if (!blockMap[block]) blockMap[block] = 0;
        blockMap[block]++;
      });

      setPieData(Object.entries(categories).map(([name, value]) => ({ name, value })));
      setOccupancyData(Object.entries(blockMap).map(([name, value]) => ({ name, value })));
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>تطبيق إدارة الساحات - YARD OPERATION</h1>
      <input type="file" accept=".xlsx, .xls" onChange={handleFileUpload} />

      {data.length > 0 && (
        <>
          <table border="1" cellPadding="5" style={{ marginTop: 20 }}>
            <thead>
              <tr>
                {Object.keys(data[0]).map((key) => (
                  <th key={key}>{key}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, idx) => (
                <tr key={idx}>
                  {Object.values(row).map((cell, i) => (
                    <td key={i}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          <h2>توزيع الحاويات حسب النوع</h2>
          <PieChart width={400} height={300}>
            <Pie data={pieData} cx="50%" cy="50%" outerRadius={100} fill="#8884d8" dataKey="value" label>
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>

          <h2>عدد الحاويات في كل ساحة</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={occupancyData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8884d8" name="عدد الحاويات" />
            </BarChart>
          </ResponsiveContainer>
        </>
      )}
    </div>
  );
}
